PyJSA
=====
A python package for the simulation of the joint spectral amplitude of output photons from an SPDC source buit in a PPLN ridge waveguide.
